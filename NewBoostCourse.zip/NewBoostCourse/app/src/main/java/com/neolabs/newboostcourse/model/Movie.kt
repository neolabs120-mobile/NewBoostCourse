package anolabs.cinemaheaven2.network

class Movie {
    var id: String? = null
    var title: String? = null
    var title_eng: String? = null
    var date: String? = null
    var user_rating: String? = null
    var audience_rating: String? = null
    var reviewer_rating: String? = null
    var reservation_rate: String? = null
    var reservation_grade: String? = null
    var grade: String? = null
    var thumb: String? = null
    var image: String? = null
}