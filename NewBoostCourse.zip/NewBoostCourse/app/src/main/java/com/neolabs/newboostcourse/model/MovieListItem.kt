package anolabs.cinemaheaven2.item

class MovieListItem(var movieName: String, var movieInfo: String, var movieImage: String, var movieId: String, var titleeng: String) 