package com.neolabs.newboostcourse.others

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}