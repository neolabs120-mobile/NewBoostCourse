package anolabs.cinemaheaven2.item

class CommentItem(var userid: String, var username: String, var usertime: String, var usercomment: String, var thumbupnumber: String, var ratingnumber: String) 