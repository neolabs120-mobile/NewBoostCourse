package anolabs.cinemaheaven2.network

class MovieDetail {
    var message: String? = null
    var code: String? = null
    var resultType: String? = null
    var result = ArrayList<Movie2>()
}