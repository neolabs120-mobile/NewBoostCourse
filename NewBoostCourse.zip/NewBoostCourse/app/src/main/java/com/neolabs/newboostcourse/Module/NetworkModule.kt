package com.neolabs.newboostcourse.Module

import com.neolabs.newboostcourse.retrofit.MovieHelper
import com.neolabs.newboostcourse.retrofit.MovieHelperImpl
import com.neolabs.newboostcourse.retrofit.MovieService
import dagger.Provides
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import okhttp3.logging.HttpLoggingInterceptor
import javax.inject.Singleton

class NetworkModule{
    fun provideBaseUrl() = "https://api.github.com"

    fun provideOkHttpClient() =
        OkHttpClient
            .Builder()
            .build()

    fun provideRetrofit(okHttpClient: OkHttpClient, BASE_URL:String): Retrofit = Retrofit.Builder()
        .addConverterFactory(GsonConverterFactory.create())
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .build()

    fun provideApiService(retrofit: Retrofit) = retrofit.create(MovieService::class.java)

    fun provideApiHelper(apiHelper: MovieHelperImpl): MovieHelper = apiHelper

}