package anolabs.cinemaheaven2.network

class CommentData {
    var id: String? = null
    var writer: String? = null
    var movieId: String? = null
    var writer_image: String? = null
    var time: String? = null
    var timestamp: String? = null
    var rating: String? = null
    var contents: String? = null
    var recommend: String? = null
}