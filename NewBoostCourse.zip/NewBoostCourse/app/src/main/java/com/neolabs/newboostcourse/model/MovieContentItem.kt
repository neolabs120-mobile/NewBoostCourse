package anolabs.cinemaheaven2.item

class MovieContentItem(var movieImageLink: String, var isMovieorImage: Boolean, var youtubelink: String) 