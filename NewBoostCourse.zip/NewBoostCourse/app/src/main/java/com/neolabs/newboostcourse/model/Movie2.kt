package anolabs.cinemaheaven2.network

class Movie2 {
    var title: String? = null
    var id: String? = null
    var date: String? = null
    var user_rating: String? = null
    var audience_rating: String? = null
    var reviewer_rating: String? = null
    var reservation_rate: String? = null
    var reservation_grade: String? = null
    var grade: String? = null
    var thumb: String? = null
    var image: String? = null
    var photos: String? = null
    var videos: String? = null
    var outlinks: String? = null
    var genre: String? = null
    var duration: String? = null
    var audience: String? = null
    var synopsis: String? = null
    var director: String? = null
    var actor: String? = null
    var like: String? = null
    var dislike: String? = null
}