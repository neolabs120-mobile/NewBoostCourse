package anolabs.cinemaheaven2.network

class MovieList {
    var message: String? = null
    var code: String? = null
    var resultType: String? = null
    var result = ArrayList<Movie>()
}