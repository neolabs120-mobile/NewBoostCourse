package anolabs.cinemaheaven2.network

class CommentList {
    var message: String? = null
    var code: String? = null
    var resultType: String? = null
    var totalCount: String? = null
    var result = ArrayList<CommentData>()
}