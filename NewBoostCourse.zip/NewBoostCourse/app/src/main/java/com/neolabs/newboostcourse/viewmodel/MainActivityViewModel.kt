package com.neolabs.newboostcourse.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import anolabs.cinemaheaven2.item.MovieListItem
import anolabs.cinemaheaven2.network.MovieList
import com.neolabs.newboostcourse.others.Resource
import com.neolabs.newboostcourse.repository.MainRepository
import kotlinx.coroutines.launch

class MainActivityViewModel(val mainRepository: MainRepository) : ViewModel() {
    private val _res = MutableLiveData<Resource<ArrayList<MovieListItem>>>()

    val res : LiveData<Resource<ArrayList<MovieListItem>>>
        get() = _res

    fun getmovielist() {
        _res.postValue(Resource.loading(null))
        viewModelScope.launch {
            mainRepository.getmovelist().let {
                if (it.isSuccessful){
                    _res.postValue(Resource.success(it.body()))
                    Log.d("whathow", it.body().toString())
                }else{
                    _res.postValue(Resource.error(it.errorBody().toString(), null))
                    Log.d("whathow", it.errorBody().toString())
                }
            }
        }
    }
}